# printm

printm is an open-source Python package providing CUI output like more/less command in Python script.

## Feature

* simple: 

* freedom: you can change placeholder and blank, etc.

## Install

``` 
$ pip install printm 
```

## Usage

```python

```
